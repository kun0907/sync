package com.dkd.emms.systemManage.bo;

public enum ProjectEnum {
    /**
     * WBS状态-- 未提交
     */
    wbsnew,
    /**
     * WBS状态-- 启用
     */
    wbspass,
    /**
     * WBS状态-- 完结
     */
    wbsfinish
}
