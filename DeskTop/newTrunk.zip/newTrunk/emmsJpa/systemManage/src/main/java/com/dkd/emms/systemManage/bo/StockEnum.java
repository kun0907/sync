package com.dkd.emms.systemManage.bo;

public enum StockEnum {
    /**
     * 库存状态-- 可用
     */
	stockUse,
    /**
     * 库存状态-- 出库完成
     */
    outStockFinish
}
