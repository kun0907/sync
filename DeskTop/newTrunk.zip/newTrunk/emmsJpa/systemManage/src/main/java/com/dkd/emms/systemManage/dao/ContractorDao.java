package com.dkd.emms.systemManage.dao;


import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.Contractor;
import org.springframework.stereotype.Repository;

/**
 * 承包商Dao
 * @author wangqian
 *
 */
@Repository
public class ContractorDao extends BaseDao<Contractor> {

}
