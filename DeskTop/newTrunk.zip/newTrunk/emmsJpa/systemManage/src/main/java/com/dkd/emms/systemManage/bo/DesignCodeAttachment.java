package com.dkd.emms.systemManage.bo;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by YUZH on 2017/2/23.
 */
public class DesignCodeAttachment {
    /**
     *设计院编码ID（设备）
     */
    private String designEId;
    /**
     * 设计院编码ID（材料）
     */
    private String designMId;
    /**
     * 配件数量
     */
    private BigDecimal attachmentNumber;
    /**
     * wbsID
     */
    private String wbsId;

    /**
     * 位号
     */
    private String equipmentNo;
    /**
     * 序号
     */
    private Integer attachmentNo;
    private String  _parentId;
    private String designType;
    public String getDesignEId() {
        return designEId;
    }

    public void setDesignEId(String designEId) {
        this.designEId = designEId;
    }

    public String getDesignMId() {
        return designMId;
    }

    public void setDesignMId(String designMId) {
        this.designMId = designMId;
    }

    public BigDecimal getAttachmentNumber() {
        return attachmentNumber;
    }

    public void setAttachmentNumber(BigDecimal attachmentNumber) {
        this.attachmentNumber = attachmentNumber;
    }

    public String getWbsId() {
        return wbsId;
    }

    public void setWbsId(String wbsId) {
        this.wbsId = wbsId;
    }

    public String getEquipmentNo() {
        return equipmentNo;
    }

    public void setEquipmentNo(String equipmentNo) {
        this.equipmentNo = equipmentNo;
    }

    public Integer getAttachmentNo() {
        return attachmentNo;
    }

    public void setAttachmentNo(Integer attachmentNo) {
        this.attachmentNo = attachmentNo;
    }

    public String get_parentId() {
        return _parentId;
    }

    public void set_parentId(String _parentId) {
        this._parentId = _parentId;
    }

    public String getDesignType() {
        return designType;
    }

    public void setDesignType(String designType) {
        this.designType = designType;
    }
}

