package com.dkd.emms.systemManage.bo;

/**
 * Created by WUJY on 2017/2/23.
 */
public class MaterialsFile {

    private String materialsTableId;//设计料表ID（系统生成）
    private String realFileName;//文件原始名称
    private byte[] contents;//二进制文件数据

    public String getMaterialsTableId() {
        return materialsTableId;
    }

    public void setMaterialsTableId(String materialsTableId) {
        this.materialsTableId = materialsTableId;
    }

    public String getRealFileName() {
        return realFileName;
    }

    public void setRealFileName(String realFileName) {
        this.realFileName = realFileName;
    }

    public byte[] getContents() {
        return contents;
    }

    public void setContents(byte[] contents) {
        this.contents = contents;
    }
}
