package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.MaterialInspect;
import org.springframework.stereotype.Repository;

/**
 * Created by YINXP on 2017/3/8.
 */
@Repository
public class MaterialInspectDao extends BaseDao<MaterialInspect> {


}
