package com.dkd.emms.systemManage.bo;

import java.math.BigDecimal;

public class MaterialsAttachement {
    /**
     * 系统编码ID（设备）
     */
    private String materialsEId;
    /**
     * 系统编码ID（材料）
     */
    private String materialsMId;
    /**
     * 配件数量
     */
    private BigDecimal attachmentNumber;
    /**
     * wbsID
     */
    private String wbsId;
    /**
     * 位号
     */
    private String equipmentNo;

    public String getMaterialsEId() {
        return materialsEId;
    }

    public void setMaterialsEId(String materialsEId) {
        this.materialsEId = materialsEId;
    }

    public String getMaterialsMId() {
        return materialsMId;
    }

    public void setMaterialsMId(String materialsMId) {
        this.materialsMId = materialsMId;
    }

    public BigDecimal getAttachmentNumber() {
        return attachmentNumber;
    }

    public void setAttachmentNumber(BigDecimal attachmentNumber) {
        this.attachmentNumber = attachmentNumber;
    }

    public String getWbsId() {
        return wbsId;
    }

    public void setWbsId(String wbsId) {
        this.wbsId = wbsId;
    }

    public String getEquipmentNo() {
        return equipmentNo;
    }

    public void setEquipmentNo(String equipmentNo) {
        this.equipmentNo = equipmentNo;
    }
}