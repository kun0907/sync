package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.InWarehouse;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/3/10.
 */
@Repository
public class InWarehouseDao extends BaseDao<InWarehouse> {
}
