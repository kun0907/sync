package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.Tree;

import java.math.BigDecimal;

/**
 * Created by YUZH on 2017/3/7.
 */
public class ReceiptPacking extends Tree {
    private String packingId;
    private String receiptId;
    private String packingNo;
    private int packingSize;
    private int packingWeight;
    private String _parentId;
    private String packingType;
    private String dianshouType;
    private String isDianshou;
    private String storageId;
    private String storageCode;
    private String deliveryPackingId;
    private BigDecimal dianshouCount;

    public String getPackingId() {
        return packingId;
    }

    public void setPackingId(String packingId) {
        this.packingId = packingId;
    }

    public String getReceiptId() {
        return receiptId;
    }

    public void setReceiptId(String receiptId) {
        this.receiptId = receiptId;
    }

    public String getPackingNo() {
        return packingNo;
    }

    public void setPackingNo(String packingNo) {
        this.packingNo = packingNo;
    }

    public int getPackingSize() {
        return packingSize;
    }

    public void setPackingSize(int packingSize) {
        this.packingSize = packingSize;
    }

    public int getPackingWeight() {
        return packingWeight;
    }

    public void setPackingWeight(int packingWeight) {
        this.packingWeight = packingWeight;
    }

    public String get_parentId() {
        return _parentId;
    }

    public void set_parentId(String _parentId) {
        this._parentId = _parentId;
    }

    public String getPackingType() {
        return packingType;
    }

    public void setPackingType(String packingType) {
        this.packingType = packingType;
    }

    public String getDianshouType() {
        return dianshouType;
    }

    public void setDianshouType(String dianshouType) {
        this.dianshouType = dianshouType;
    }

    public String getIsDianshou() {
        return isDianshou;
    }

    public void setIsDianshou(String isDianshou) {
        this.isDianshou = isDianshou;
    }

    public String getStorageId() {
        return storageId;
    }

    public void setStorageId(String storageId) {
        this.storageId = storageId;
    }

    public String getStorageCode() {
        return storageCode;
    }

    public void setStorageCode(String storageCode) {
        this.storageCode = storageCode;
    }

    public String getDeliveryPackingId() {
        return deliveryPackingId;
    }

    public void setDeliveryPackingId(String deliveryPackingId) {
        this.deliveryPackingId = deliveryPackingId;
    }

    public BigDecimal getDianshouCount() {
        return dianshouCount;
    }

    public void setDianshouCount(BigDecimal dianshouCount) {
        this.dianshouCount = dianshouCount;
    }
}
