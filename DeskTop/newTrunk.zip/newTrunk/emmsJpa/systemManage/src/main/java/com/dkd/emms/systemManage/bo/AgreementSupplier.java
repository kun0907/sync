package com.dkd.emms.systemManage.bo;

/**
 * Created by Administrator on 2017/2/22.
 */


        import com.dkd.emms.core.entity.BaseEntity;

public class AgreementSupplier extends BaseEntity {
    /**
     *
     * 来源单据类型（框架协议、采购合同（订单））
     *
     *
     */
    private String sourceState;

    /**
     *
     * 来源单据ID
     *
     *
     */
    private String sourceId;

    /**
     *
     * 供应商ID
     *
     *
     */
    private String supplierOrgId;

    /**
     *
     * 供应商框架协议号
     *
     *
     */

    private String supplierAgreementCode;
    /**
     * 组织机构Name
     */
    private String orgName;
    /**
     * 组织机构Code
     */
    private String orgCode;


    public String getSourceState() {
        return sourceState;
    }


    public void setSourceState(String sourceState) {
        this.sourceState = sourceState;
    }


    public String getSourceId() {
        return sourceId;
    }


    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }


    public String getSupplierOrgId() {
        return supplierOrgId;
    }


    public void setSupplierOrgId(String supplierOrgId) {
        this.supplierOrgId = supplierOrgId;
    }


    public String getSupplierAgreementCode() {
        return supplierAgreementCode;
    }


    public void setSupplierAgreementCode(String supplierAgreementCode) {
        this.supplierAgreementCode = supplierAgreementCode;
    }
    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
}
