package com.dkd.emms.systemManage.bo;

public enum DeliveryEnum {
    /**
     * 发货单状态-- 新建
     */
	deliveryNew,
   /* *//**
     * 发货单状态-- 提交
     *//*
    deliverCommit,*/
    /**
     * 发货单状态-- 发货
     */
    delivery
}
