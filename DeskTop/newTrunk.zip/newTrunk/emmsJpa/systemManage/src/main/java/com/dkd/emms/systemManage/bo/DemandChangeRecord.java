package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by YUZH on 2017/3/21.
 */
public class DemandChangeRecord extends BaseEntity {
    private String demandId;
    private String demandDetailId;
    private String changeId;
    private Date changeDate;
    private BigDecimal changeCount;

    public String getDemandId() {
        return demandId;
    }

    public void setDemandId(String demandId) {
        this.demandId = demandId;
    }

    public String getDemandDetailId() {
        return demandDetailId;
    }

    public void setDemandDetailId(String demandDetailId) {
        this.demandDetailId = demandDetailId;
    }

    public String getChangeId() {
        return changeId;
    }

    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public BigDecimal getChangeCount() {
        return changeCount;
    }

    public void setChangeCount(BigDecimal changeCount) {
        this.changeCount = changeCount;
    }
}
