package com.dkd.emms.systemManage.dao;
import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.Agreement;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/2/22.
 */
@Repository
public class AgreementDao extends BaseDao<Agreement>{


}
