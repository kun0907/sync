package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.TransportInfo;
import org.springframework.stereotype.Repository;

/**
 * Created by YINXP on 2017/4/25.
 */
@Repository
public class TransportInfoDao extends BaseDao<TransportInfo> {
}
