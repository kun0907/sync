package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.BaseEntity;

import java.math.BigDecimal;

/**
 * Created by YUZH on 2017/3/21.
 */
public class DemandDrawing extends BaseEntity {
    private String drawingId;
    private String wbsId;
    private String designCode;
    private String materialsId;
    private String drawingNumberCode;
    private Integer drawingNumberVersion;
    private BigDecimal designCount;
    private BigDecimal demandCount;

    public String getDrawingId() {
        return drawingId;
    }

    public void setDrawingId(String drawingId) {
        this.drawingId = drawingId;
    }

    public String getWbsId() {
        return wbsId;
    }

    public void setWbsId(String wbsId) {
        this.wbsId = wbsId;
    }

    public String getDesignCode() {
        return designCode;
    }

    public void setDesignCode(String designCode) {
        this.designCode = designCode;
    }

    public String getMaterialsId() {
        return materialsId;
    }

    public void setMaterialsId(String materialsId) {
        this.materialsId = materialsId;
    }

    public String getDrawingNumberCode() {
        return drawingNumberCode;
    }

    public void setDrawingNumberCode(String drawingNumberCode) {
        this.drawingNumberCode = drawingNumberCode;
    }

    public Integer getDrawingNumberVersion() {
        return drawingNumberVersion;
    }

    public void setDrawingNumberVersion(Integer drawingNumberVersion) {
        this.drawingNumberVersion = drawingNumberVersion;
    }

    public BigDecimal getDesignCount() {
        return designCount;
    }

    public void setDesignCount(BigDecimal designCount) {
        this.designCount = designCount;
    }

    public BigDecimal getDemandCount() {
        return demandCount;
    }

    public void setDemandCount(BigDecimal demandCount) {
        this.demandCount = demandCount;
    }
}
