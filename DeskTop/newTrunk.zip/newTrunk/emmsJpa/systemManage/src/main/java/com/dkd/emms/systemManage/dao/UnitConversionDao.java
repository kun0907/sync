package com.dkd.emms.systemManage.dao;

import org.springframework.stereotype.Repository;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.UnitConversion;



@Repository
public class UnitConversionDao extends BaseDao<UnitConversion> {

}
