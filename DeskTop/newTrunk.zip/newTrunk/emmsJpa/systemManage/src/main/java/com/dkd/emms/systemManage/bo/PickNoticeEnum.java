package com.dkd.emms.systemManage.bo;

public enum PickNoticeEnum {
    /**
     * 领料通知-- 新建
     */
	pickNoticeNew,
    /**
     * 领料通知-- 提交
     */
    pickNoticeCommit,

    /**
     * 领料通知--失效
     */
    pickNoticeInvalid
}
