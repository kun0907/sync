package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.BaseEntity;
import com.dkd.emms.core.entity.Tree;

import java.util.List;

/**
 * Created by YUZH on 2017/4/25.
 */
public class Process extends Tree {
    private String processId;
    private String processName;
    private String processType;
    private List<ProcessDetail> processDetailList;
    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public List<ProcessDetail> getProcessDetailList() {
        return processDetailList;
    }

    public void setProcessDetailList(List<ProcessDetail> processDetailList) {
        this.processDetailList = processDetailList;
    }
}
