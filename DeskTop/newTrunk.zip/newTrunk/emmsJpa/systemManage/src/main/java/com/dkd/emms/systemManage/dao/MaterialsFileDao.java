package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.MaterialsFile;
import org.springframework.stereotype.Repository;

/**
 * Created by WUJY on 2017/2/23.
 */
@Repository
public class MaterialsFileDao extends BaseDao<MaterialsFile> {

}
