package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.BaseEntity;

import java.util.Date;
import java.util.List;

/**
 * Created by YUZH on 2017/4/26.
 */
public class ProcessRecord extends BaseEntity {
    private String precessRecordId;
    private String processRecordEntity;
    private String processRecordEntityId;
    private Boolean isFinish;
    private Integer sequence;
    private Date summitTime;
    private List<ProcessRecordDetail> processRecordDetailList;
    public String getPrecessRecordId() {
        return precessRecordId;
    }

    public void setPrecessRecordId(String precessRecordId) {
        this.precessRecordId = precessRecordId;
    }

    public String getProcessRecordEntity() {
        return processRecordEntity;
    }

    public void setProcessRecordEntity(String processRecordEntity) {
        this.processRecordEntity = processRecordEntity;
    }

    public String getProcessRecordEntityId() {
        return processRecordEntityId;
    }

    public void setProcessRecordEntityId(String processRecordEntityId) {
        this.processRecordEntityId = processRecordEntityId;
    }

    public Boolean getIsFinish() {
        return isFinish;
    }

    public void setIsFinish(Boolean isFinish) {
        this.isFinish = isFinish;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public List<ProcessRecordDetail> getProcessRecordDetailList() {
        return processRecordDetailList;
    }

    public void setProcessRecordDetailList(List<ProcessRecordDetail> processRecordDetailList) {
        this.processRecordDetailList = processRecordDetailList;
    }

    public Date getSummitTime() {
        return summitTime;
    }

    public void setSummitTime(Date summitTime) {
        this.summitTime = summitTime;
    }
}
