package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.DemandPlan;
import org.springframework.stereotype.Repository;

/**
 * Created by YUZH on 2017/3/16.
 */
@Repository
public class DemandPlanDao extends BaseDao<DemandPlan> {
}
