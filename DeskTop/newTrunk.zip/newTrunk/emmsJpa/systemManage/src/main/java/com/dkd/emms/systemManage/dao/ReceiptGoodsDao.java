package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.ReceiptGoods;
import org.springframework.stereotype.Repository;

/**
 * Created by YUZH on 2017/3/6.
 */
@Repository
public class ReceiptGoodsDao extends BaseDao<ReceiptGoods> {
}
