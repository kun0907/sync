package com.dkd.emms.systemManage.bo;

public enum RoleEnum {
    /**
     * 系统级角色
     */
    sys_level,
    /**
     * 应用级角色
     */
    app_level,
    /**
     * 非单据角色
     */
    noDoc_level,
}
