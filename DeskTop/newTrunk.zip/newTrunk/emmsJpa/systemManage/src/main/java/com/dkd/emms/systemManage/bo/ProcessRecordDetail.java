package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.BaseEntity;

import java.util.Date;

/**
 * Created by YUZH on 2017/4/26.
 */
public class ProcessRecordDetail extends BaseEntity {
    private String RecordDetailId;
    private String precessRecordId;
    private Date approveTime;
    private String approveUserId;
    private String approveUserName;
    private Boolean isApprove;
    private String processDetailId;
    private Integer sequence;
    private String roleId;
    private String roleName;
    public String getRecordDetailId() {
        return RecordDetailId;
    }

    public void setRecordDetailId(String recordDetailId) {
        RecordDetailId = recordDetailId;
    }

    public String getPrecessRecordId() {
        return precessRecordId;
    }

    public void setPrecessRecordId(String precessRecordId) {
        this.precessRecordId = precessRecordId;
    }

    public Date getApproveTime() {
        return approveTime;
    }

    public void setApproveTime(Date approveTime) {
        this.approveTime = approveTime;
    }

    public String getApproveUserId() {
        return approveUserId;
    }

    public void setApproveUserId(String approveUserId) {
        this.approveUserId = approveUserId;
    }

    public String getApproveUserName() {
        return approveUserName;
    }

    public void setApproveUserName(String approveUserName) {
        this.approveUserName = approveUserName;
    }

    public Boolean getIsApprove() {
        return isApprove;
    }

    public void setIsApprove(Boolean isApprove) {
        this.isApprove = isApprove;
    }

    public String getProcessDetailId() {
        return processDetailId;
    }

    public void setProcessDetailId(String processDetailId) {
        this.processDetailId = processDetailId;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
