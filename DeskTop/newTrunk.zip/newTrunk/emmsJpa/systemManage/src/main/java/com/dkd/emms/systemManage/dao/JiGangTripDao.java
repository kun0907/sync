package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.JiGangTrip;
import org.springframework.stereotype.Repository;

/**
 * Created by YINXP on 2017/4/26.
 */
@Repository
public class JiGangTripDao extends BaseDao<JiGangTrip> {
}
