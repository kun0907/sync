package com.dkd.emms.systemManage.bo;

import com.dkd.emms.core.entity.Tree;

/**
 * 字典类
 * @author sy
 * 
 */

public class Dictionary extends Tree {

	private String dictionaryId;// 字典ID
	private String dictionaryCode;// 字典编码
	private String dictionaryName;// 字典名称
	private int isDel;// 标记删除(1:在用，0:弃用)
	private int dictionaryType;//字典类型(1:数据字典，0:业务字典)
	
	public String getDictionaryId() {
		return dictionaryId;
	}
	public void setDictionaryId(String dictionaryId) {
		this.dictionaryId = dictionaryId;
	}
	public String getDictionaryCode() {
		return dictionaryCode;
	}
	public void setDictionaryCode(String dictionaryCode) {
		this.dictionaryCode = dictionaryCode;
	}
	public String getDictionaryName() {
		return dictionaryName;
	}
	public void setDictionaryName(String dictionaryName) {
		this.dictionaryName = dictionaryName;
	}
	public int getIsDel() {
		return isDel;
	}
	public void setIsDel(int isDel) {
		this.isDel = isDel;
	}
	public int getDictionaryType() {
		return dictionaryType;
	}
	public void setDictionaryType(int dictionaryType) {
		this.dictionaryType = dictionaryType;
	}
	
}
