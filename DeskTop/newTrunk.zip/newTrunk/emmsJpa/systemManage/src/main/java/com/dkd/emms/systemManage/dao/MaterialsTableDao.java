/**
 * 
 */
package com.dkd.emms.systemManage.dao;

import com.dkd.emms.core.dao.BaseDao;
import com.dkd.emms.systemManage.bo.MaterialsTable;
import org.springframework.stereotype.Repository;


/**
* @Title: MaterialsTableDao
* @Description:
* @param
* @author:YUZH
* @data 2017年1月24日
*/
@Repository
public class MaterialsTableDao extends BaseDao<MaterialsTable>{

}
