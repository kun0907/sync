package com.dkd.emms.core;

public  class Constant {
	/** 项目管理 start*/
	/**
	 * 主项目
	 */
	public static final String PROJECT_IS_MAIN = "1";
	/**
	 * 非主项目
	 */
	public static final String PROJECT_NOT_MAIN = "0";
	/**
	 * 项目新建状态
	 */
	public static final String PROJECT_STATE_NEW = "new";
	/**
	 * 项目启用状态
	 */
	public static final String PROJECT_STATE_START = "start";
	/** 项目管理 end*/
	
	/** 组织机构管理 start*/
	/**
	 * 组织机构有效
	 */
	public static final String ORG_IS_VALIDATE = "1";
	
	/**
	 * 组织机构未删除
	 */
	public static final String ORG_NO_DEL = "0";
	
	/**组织机构管理 end*/
	
	/** 人员管理 start*/
	/**
	 * 人员状态(在岗)
	 */
	public static final String EMP_WORKING = "1";
	/**
	 * 人员状态(离职)
	 */
	public static final String EMP_QUIT = "0";
	
	/**
	 * 人员性别(男)
	 */
	public static final String EMP_SEX = "male";
	
	/**人员管理 end*/
	
	/** 角色管理 start*/
	/**
	 * 角色未删除状态
	 */
	public static final String ROLE_NO_DEL = "0";
	
	/**
	 * 角色类型:系统级权限
	public static final String SYS_ROLE_TYPE = "sys_level";
	*
	 * 角色类型:应用级权限
	public static final String APP_ROLE_TYPE = "app_level";
	* 角色管理 end*/
}
