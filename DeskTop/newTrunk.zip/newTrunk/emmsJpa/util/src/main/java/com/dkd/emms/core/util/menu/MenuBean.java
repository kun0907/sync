package com.dkd.emms.core.util.menu;

import java.util.List;

/**
 * 菜单bean
 * @author SY
 *
 */

public class MenuBean {
	
	private List<SysMenu> sysMenuList;

	public List<SysMenu> getSysMenuList() {
		return sysMenuList;
	}
	public void setSysMenuList(List<SysMenu> sysMenuList) {
		this.sysMenuList = sysMenuList;
	}
	
}
