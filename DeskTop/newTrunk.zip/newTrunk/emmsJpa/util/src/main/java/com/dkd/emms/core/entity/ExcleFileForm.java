package com.dkd.emms.core.entity;

import org.springframework.web.multipart.MultipartFile;

public class ExcleFileForm {

	private String designOrgId;//设计院ID
	private String materialsTableType;//料表类型


	public String getDesignOrgId() {
		return designOrgId;
	}

	public void setDesignOrgId(String designOrgId) {
		this.designOrgId = designOrgId;
	}

	public String getMaterialsTableType() {
		return materialsTableType;
	}

	public void setMaterialsTableType(String materialsTableType) {
		this.materialsTableType = materialsTableType;
	}
	
}
