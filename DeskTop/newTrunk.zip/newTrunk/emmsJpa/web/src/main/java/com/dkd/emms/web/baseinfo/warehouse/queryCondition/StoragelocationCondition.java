/**
 * 
 */
package com.dkd.emms.web.baseinfo.warehouse.queryCondition;

import com.dkd.emms.core.entity.BaseEntity;

	/**
 * @Title: StoragelocationCondition
 * @Description:
 * @param 
 * @author:YUZH 
 * @data 2017年2月8日
 */
public class StoragelocationCondition extends BaseEntity{
	private String storagelocationCode;//储位编码
	private String storagelocationName;//储位名称
	private String storagelocationType;//储位类型
	private String state;//状态
	private String reservoirareaId;//库区ID
	private String warehouseId;//仓库ID
	
	public String getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(String warehouseId) {
		this.warehouseId = warehouseId;
	}
	public String getStoragelocationCode() {
		return storagelocationCode;
	}
	public void setStoragelocationCode(String storagelocationCode) {
		this.storagelocationCode = storagelocationCode;
	}
	public String getStoragelocationName() {
		return storagelocationName;
	}
	public void setStoragelocationName(String storagelocationName) {
		this.storagelocationName = storagelocationName;
	}
	public String getStoragelocationType() {
		return storagelocationType;
	}
	public void setStoragelocationType(String storagelocationType) {
		this.storagelocationType = storagelocationType;
	}
	public String getReservoirareaId() {
		return reservoirareaId;
	}
	public void setReservoirareaId(String reservoirareaId) {
		this.reservoirareaId = reservoirareaId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
