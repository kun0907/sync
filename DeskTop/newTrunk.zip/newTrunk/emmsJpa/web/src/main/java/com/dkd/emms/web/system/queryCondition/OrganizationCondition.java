package com.dkd.emms.web.system.queryCondition;


/**
 * 组织机构查询条件
 * @author WANGQ
 *
 */
public class OrganizationCondition  {
	/**
	 * 父节点Id
	 */
	private String parentId;
	/**
	 * 社会统一信用代码
	 */
	private String orgCode;
	/**
	 * 组织名称
	 */
	private String orgName;
	/**
	 * 组织类型
	 */
	private String orgType;
	/**
	 * 组织状态
	 */
	private String orgState;
	
	/**
	 * 当前页
	 */
	private String orgId;

	
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getOrgState() {
		return orgState;
	}
	public void setOrgState(String orgState) {
		this.orgState = orgState;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
}
