package com.dkd.emms.web.purchase.transportInfo.queryCondition;

import com.dkd.emms.core.entity.BaseEntity;

/**
 * Created by YINXP on 2017/4/27.
 */
public class TransportInfoDetailCondition extends BaseEntity {

}
