package com.dkd.emms.web.instorage.materialInspect.queryCondition;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by YINXP on 2017/3/8.
 */
public class MaterialInspectCondition {
     private String inspectNo;//质检单编号
     private String inspectStaus;//单据状态
     private String supplierName;//供应商名称
     private String createUserName;//创建人
     private String materiaInspectId;//质检单ID
     private String dataSource;//数据来源
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createStartTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createEndTime;


    public String getInspectNo() {
        return inspectNo;
    }

    public void setInspectNo(String inspectNo) {
        this.inspectNo = inspectNo;
    }

    public String getInspectStaus() {
        return inspectStaus;
    }

    public void setInspectStaus(String inspectStaus) {
        this.inspectStaus = inspectStaus;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public String getMateriaInspectId() {
        return materiaInspectId;
    }

    public void setMateriaInspectId(String materiaInspectId) {
        this.materiaInspectId = materiaInspectId;
    }

    public Date getCreateEndTime() {
        return createEndTime;
    }

    public void setCreateEndTime(Date createEndTime) {
        this.createEndTime = createEndTime;
    }

    public Date getCreateStartTime() {
        return createStartTime;
    }

    public void setCreateStartTime(Date createStartTime) {
        this.createStartTime = createStartTime;
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }
}
