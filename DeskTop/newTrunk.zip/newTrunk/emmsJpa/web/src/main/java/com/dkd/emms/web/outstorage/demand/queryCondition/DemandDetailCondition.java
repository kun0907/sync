package com.dkd.emms.web.outstorage.demand.queryCondition;

/**
 * Created by YUZH on 2017/3/21.
 */
public class DemandDetailCondition {
    private String demandCode;
    private String demandOrgId;

    public String getDemandCode() {
        return demandCode;
    }

    public void setDemandCode(String demandCode) {
        this.demandCode = demandCode;
    }

    public String getDemandOrgId() {
        return demandOrgId;
    }

    public void setDemandOrgId(String demandOrgId) {
        this.demandOrgId = demandOrgId;
    }
}
