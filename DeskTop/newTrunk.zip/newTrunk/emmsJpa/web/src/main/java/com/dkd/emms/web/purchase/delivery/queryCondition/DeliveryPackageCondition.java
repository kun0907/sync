package com.dkd.emms.web.purchase.delivery.queryCondition;

/**
 * 供应商发货查询条件
 * Created by wangqian on 2017/2/24.
 */
public class DeliveryPackageCondition {
    /**
     * 发货单号
     */
    private String deliveryNo;

    /**
     * 供应商Id
     */
    private String supplierId;

    public String getDeliveryNo() {
        return deliveryNo;
    }

    public void setDeliveryNo(String deliveryNo) {
        this.deliveryNo = deliveryNo;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }
}


