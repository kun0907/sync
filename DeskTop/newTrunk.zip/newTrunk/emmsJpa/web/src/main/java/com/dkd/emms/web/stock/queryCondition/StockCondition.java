package com.dkd.emms.web.stock.queryCondition;

/**
 * Created by wangqian on 2017/3/20.
 */
public class StockCondition {
    /**
     * 项目编码
     */
    private String wbsCode;
    /**
     * 库存状态
     */
    private String stockState;
    /**
     * 储位编码
     */
    private String storagelocationCode;

    public String getWbsCode() {
        return wbsCode;
    }

    public void setWbsCode(String wbsCode) {
        this.wbsCode = wbsCode;
    }

    public String getStockState() {
        return stockState;
    }

    public void setStockState(String stockState) {
        this.stockState = stockState;
    }

    public String getStoragelocationCode() {
        return storagelocationCode;
    }

    public void setStoragelocationCode(String storagelocationCode) {
        this.storagelocationCode = storagelocationCode;
    }
}
