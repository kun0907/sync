package com.dkd.emms.web.system.queryCondition;
/**
 * 权限查询条件
 * @author WANGQ
 *
 */
public class ResourceCondition {
	/**
	 * 父节点id
	 */
	private  String parentId;

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
}
