package com.dkd.emms.web.instorage.materialInspect.queryCondition;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Administrator on 2017/2/28.
 */
public class QualityInspectDetailCondition {
    private String receiptCode;//收货单编号
    private String materiaInspectId;//质检单ID
    private String materialsCode;
    private String packingNo;//包裝編號
    private String inspectNo;//质检单编号
    private String deliveryId;//收货单ID
    private String supplierId;//供应商ID

    public String getReceiptCode() {
        return receiptCode;
    }

    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }

    public String getMateriaInspectId() {
        return materiaInspectId;
    }

    public void setMateriaInspectId(String materiaInspectId) {
        this.materiaInspectId = materiaInspectId;
    }

    public String getMaterialsCode() {
        return materialsCode;
    }

    public void setMaterialsCode(String materialsCode) {
        this.materialsCode = materialsCode;
    }

    public String getPackingNo() {
        return packingNo;
    }

    public void setPackingNo(String packingNo) {
        this.packingNo = packingNo;
    }

    public String getInspectNo() {
        return inspectNo;
    }

    public void setInspectNo(String inspectNo) {
        this.inspectNo = inspectNo;
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }
}
