package com.dkd.emms.web.system.queryCondition;

/**
 * Created by YUZH on 2017/4/25.
 */
public class ProcessCondition {
    private String processId;
    private String roleId;
    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}
