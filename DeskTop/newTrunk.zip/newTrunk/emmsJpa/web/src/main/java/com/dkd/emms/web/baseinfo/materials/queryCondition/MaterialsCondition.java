package com.dkd.emms.web.baseinfo.materials.queryCondition;


public class MaterialsCondition {
	/**
	 * 物资编码
	 */
	private String materialsCode;
	/**
	 * 物资描述
	 */
	private String materialsDescribe;
	/**
	 * 物料类别
	 */
	private String materialsCategory;
	/**
	 * 录入人
	 */
	private String createUserName;
	/**
	 * 开始时间
	 */
	private String beginTime;
	/**
	 * 结束时间
	 */
	private String endTime;
	/**
	 * 物资状态
	 */
	private String materialsState;
	public String getMaterialsCode() {
		return materialsCode;
	}
	public void setMaterialsCode(String materialsCode) {
		this.materialsCode = materialsCode;
	}
	public String getMaterialsDescribe() {
		return materialsDescribe;
	}
	public void setMaterialsDescribe(String materialsDescribe) {
		this.materialsDescribe = materialsDescribe;
	}
	public String getMaterialsCategory() {
		return materialsCategory;
	}
	public void setMaterialsCategory(String materialsCategory) {
		this.materialsCategory = materialsCategory;
	}
	public String getCreateUserName() {
		return createUserName;
	}
	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getMaterialsState() {
		return materialsState;
	}
	public void setMaterialsState(String materialsState) {
		this.materialsState = materialsState;
	}
}