package com.dkd.emms.web.instorage.materialInspect.queryCondition;

import java.util.List;

/**
 * Created by Administrator on 2017/3/1.
 */
public class QualityInspectPicFileCondition {

    private String inspectPicFileId;//图片id
    private String materiaInspectId;//质检单id
    private String realFileName;//文件原始名称


    public String getInspectPicFileId() {
        return inspectPicFileId;
    }

    public void setInspectPicFileId(String inspectPicFileId) {
        this.inspectPicFileId = inspectPicFileId;
    }

    public String getMateriaInspectId() {
        return materiaInspectId;
    }

    public void setMateriaInspectId(String materiaInspectId) {
        this.materiaInspectId = materiaInspectId;
    }

    public String getRealFileName() {
        return realFileName;
    }

    public void setRealFileName(String realFileName) {
        this.realFileName = realFileName;
    }
}
